A free portfolio for a guy on discord, my first project using Astro! And it's quite cool!
